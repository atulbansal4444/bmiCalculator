import UIKit

func calBMI(weight : Double,height : Double) ->Double {
    let BMI = weight / pow(height , 2)  //weight in KG and hright in meters
    return BMI
}

var Bmi = calBMI(weight: 100, height: 5)
print(Bmi)
